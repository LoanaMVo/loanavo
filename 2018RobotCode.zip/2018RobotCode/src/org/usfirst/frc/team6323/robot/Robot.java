/*----------------------------------------------------------------------------*/
/* 2018 Robotics Power-Up 	                                                  */
/* 16x encoder 				    						                      */
/* Written for CAN TalonSRX motors with 2018 CTRE and Driver Station update   */
/* Written: Loana Vo & Nils Forssen   										  */									
/* http://roborio-6323-frc.local/ <-- Webbased configuration                  */
/* Last Updated: 2018-03-05                                                   */
/*----------------------------------------------------------------------------*/

package org.usfirst.frc.team6323.robot;

import com.ctre.phoenix.ParamEnum;
import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.LimitSwitchNormal;
import com.ctre.phoenix.motorcontrol.LimitSwitchSource;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import edu.wpi.first.wpilibj.ADXRS450_Gyro;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
																					
/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the build.properties file in the
 * project.
 */
public class Robot extends IterativeRobot {
	//MOTOR NAMES
		private Spark leftIntake, rightIntake;
		private WPI_TalonSRX FLMotor, RLSlaveMotor, FRMotor, RRSlaveMotor, elevator, climb;
	//JOYSTICK
		private Joystick joystickOne, joystickTwo;
	//DRIVE TRAIN
		private DifferentialDrive myRobot;
	//ELEVATOR
		int level =0;
	//SENSORS
		private ADXRS450_Gyro gyro;
		private Encoder encoder;
	//AUTO VARIABLES
		double gyroAngle;
		double speed = 0.0;
		double error = 0.0;
		String reset;
		boolean timeStart;
		double previous = 0;
		int schedule;
		boolean reached = false;
		double integralAdjusted_driveStraight = 0;
		double integralAngle_driveStraight = 0;
		double count;
		double left;
		double right;
		String gameData;
		boolean toggle;
	//AUTO SELECTION
		private static final String kDefaultAuto = "Default";	
		private static final String fmsCenter = "FMS Data Auto from Center";
		private static final String fmsRSide = "FMS Data Auto from Right Side";
		private static final String fmsLSide = "FMS Data Auto from Left Side";
		private static final String straightAuto = "Straight";
		private String m_autoSelected;
		private SendableChooser<String> m_chooser = new SendableChooser<>();
		boolean expire = false;
		
	/**
	 * This function is run when the robot is first started up and should be
	 * used for any initialization code.
	 */
	@Override
	public void robotInit() {
		//JOYSTICK
			joystickOne = new Joystick(0);
			joystickTwo = new Joystick(1);
		//DRIVE MOTORS
			FLMotor = new WPI_TalonSRX(1);
			FRMotor = new WPI_TalonSRX(3);
			FLMotor.setInverted(true);
		//SLAVE MOTORS
			RLSlaveMotor = new WPI_TalonSRX(2);
			RRSlaveMotor = new WPI_TalonSRX(4);
			RLSlaveMotor.setInverted(true);
		//SET SLAVE
			RRSlaveMotor.follow(FRMotor);
			RLSlaveMotor.follow(FLMotor);
		//CLIMBER
			climb = new WPI_TalonSRX(6);
			climb.setInverted(true);
			/* limit switches enabled*/
			climb.configReverseLimitSwitchSource(LimitSwitchSource.FeedbackConnector, LimitSwitchNormal.NormallyClosed, 0);
			climb.configForwardLimitSwitchSource(LimitSwitchSource.FeedbackConnector, LimitSwitchNormal.NormallyClosed, 0);
			climb.overrideLimitSwitchesEnable(true);	
			/* set the  peak and nominal outputs, 12V means full */
			climb.configNominalOutputForward(0, 0);
			climb.configNominalOutputReverse(0, 0);
			climb.configPeakOutputForward(1, 0);
			climb.configPeakOutputReverse(-1, 0);
		//ELEVATOR
			elevator = new WPI_TalonSRX(5);
			/* limit switches enabled*/
			elevator.configReverseLimitSwitchSource(LimitSwitchSource.FeedbackConnector, LimitSwitchNormal.NormallyOpen, 0);
			elevator.configForwardLimitSwitchSource(LimitSwitchSource.FeedbackConnector, LimitSwitchNormal.NormallyOpen, 0);
			elevator.overrideLimitSwitchesEnable(true);		
			//sensors
			elevator.configSelectedFeedbackSensor(FeedbackDevice.QuadEncoder, 0, 0);	
			//Clear position on limit switch
			elevator.configSetParameter(ParamEnum.eClearPosOnLimitR, 0, 0, 0, 0);
			elevator.configSetParameter(ParamEnum.eClearPosOnLimitF, 1, 0, 0, 0);
			elevator.configSetParameter(ParamEnum.eClearPositionOnIdx, 0, 0, 0, 0);
			//constants
			elevator.config_kF(0, 0.0, 0);
			elevator.config_kP(0, 1, 0);
			elevator.config_kI(0, 0.001, 0);
			elevator.config_kD(0, 0.0, 0);				
			//invert
			elevator.setInverted(false);		
			elevator.setSensorPhase(true);
			/* set the  peak and nominal outputs, 12V  hi programmer means full */
			elevator.configNominalOutputForward(0, 0);
			elevator.configNominalOutputReverse(0, 0);
			elevator.configPeakOutputForward(0.5, 0);
			elevator.configPeakOutputReverse(-0.7, 0);
			//closed loop error
			elevator.configAllowableClosedloopError(0, 60, 0);
			elevator.setSelectedSensorPosition(0, 0 ,0);
			
		//ROBOT DRIVE
			myRobot = new DifferentialDrive(FLMotor, FRMotor);
			myRobot.setDeadband(0.05);
		//INTAKE
			leftIntake = new Spark(0);
			rightIntake = new Spark(1);
			rightIntake.setInverted(true);
		//SENSORS	
			CameraServer.getInstance().startAutomaticCapture();
			gyro = new ADXRS450_Gyro();
			gyro.reset();
			encoder = new Encoder(0, 1, true, Encoder.EncodingType.k4X);
			encoder.reset();
		//AUTO STRING	
			m_chooser.addDefault("Default Auto", kDefaultAuto);
			m_chooser.addObject("FMS Data Auto from Center", fmsCenter);
			m_chooser.addObject("FMS Data Auto from Right Side", fmsRSide);
			m_chooser.addObject("FMS Data Auto from Left Side", fmsLSide);	
			m_chooser.addObject("Straight", straightAuto);
			SmartDashboard.putData("Auto choices", m_chooser);
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select
	 * between different autonomous modes using the dashboard. The sendable
	 * chooser code works with the Java SmartDashboard. If you prefer the
	 * LabVIEW Dashboard, remove all of the chooser code and uncomment the
	 * getString line to get the auto name from the text box below the Gyro
	 *
	 * <p>You can add additional auto modes by adding additional comparisons to
	 * the switch structure below with additional strings. If using the
	 * SendableChooser make sure to add them to the chooser code above as well.
	 */
	@Override
	public void autonomousInit() {
		rightIntake.set(0);
		leftIntake.set(0);
		elevator.set(0);
		myRobot.setSafetyEnabled(false);
		//auto variables
		expire = false;
		schedule = 0;
		timeStart = true;
		reached = false;
		toggle = true;
		//gyro
		gyro.reset();
		//encoder
		encoder.reset();
		integralAdjusted_driveStraight = 0;
		integralAngle_driveStraight = 0;
		//string
		gameData = DriverStation.getInstance().getGameSpecificMessage();
		//auto
		m_autoSelected = m_chooser.getSelected();
		// autoSelected = SmartDashboard.getString("Auto Selector",
		// defaultAuto);
		System.out.println("Auto selected: " + m_autoSelected);
	}

	/**
	 * This function is called periodically during autonomous.
	 */
	@Override
	public void autonomousPeriodic() {
		switch (m_autoSelected) {
		case fmsCenter: //Auto based on FMS from center start			
			centerOne();
			break;	
		case fmsRSide: //Auto based on FMS from side start
			rightSide();
			break;
		case fmsLSide:
			leftSide();
			break;
		case straightAuto: //Auto for straight driving
			straight();
			break;
		case kDefaultAuto: //default
		default:
			// Put default auto code here
			break;
		}
	}
	
	/**
	 * <b>Field Managment System Auto - Center</b>
	 * <br> Gets gama data string for first route.
	 * <br> Starting position at line inbetween station 2-3
	 */
	public void centerOne() {
		SmartDashboard.putNumber("Schedule", schedule);
		SmartDashboard.putNumber("Angle", gyroAngle);
		if(gameData.charAt(0) == 'L') {//left auto
			if(schedule == 0){	
				driveStraight(30, getDistance(), 0, false, 0);		
			}else if(schedule == 1){
				turn(-90, false);						
			}else if(schedule == 2){
				driveStraight(260, getDistance(), -90, false, 0);
			}else if(schedule == 3){
				turn(0, false);
			}else if(schedule == 4){
				autoElevator(1500);
			}else if(schedule == 5) {
				driveStraight(230, getDistance(), 0, true, 5);		
			}else if(schedule == 6){
				autoIntake();
			}else{
				myRobot.setSafetyEnabled(true);
				}
		}else if(gameData.charAt(0) == 'R'){//right auto
			if(schedule == 0){
				autoElevator(1500);
			}else if(schedule == 1) {// use to be 275 !!!
				driveStraight(275, getDistance(), 0, true, 8);	
			}else if(schedule == 2){
				autoIntake();
			}else {	
				myRobot.setSafetyEnabled(true);
			}
		}
	}
	
	/**
	 * <b>Field Managment System Auto - right side</b>
	 * <br> Gets gama data string for first route.
	 * <br> Drives straight to the side of the switch then turns into the switch.
	 */
	public void rightSide() {
		SmartDashboard.putNumber("Angle", gyroAngle);
		if(gameData.charAt(0) == 'L') { //left auto
			if(schedule == 0){
				driveStraight(550, getDistance(), 0, false, 0);		
			}else if(schedule == 1) {
				turn(-90, false);
			}else if(schedule == 2) {
				driveStraight(585, getDistance(), -90, false, 0);
			}else if(schedule == 3) {
				turn(-180, false);
			}else if(schedule == 4) {	
				driveStraight(123, getDistance(), -180, false, 0);
			}else if(schedule == 5){
				turn(90, false);
			}else if(schedule == 6) {
				autoElevator(1500);
			}else if(schedule == 7) {
				driveStraight(60, getDistance(), 90, true, 5);
			}else if(schedule == 8) {
				autoIntake();
			}else {
				myRobot.setSafetyEnabled(true);
			}
		}else if(gameData.charAt(0) == 'R'){ //right auto
			if(schedule == 0){
				driveStraight(400, getDistance(), 0, false, 0);	
			}else if(schedule == 1){
				turn(-90, true);		
			}else if(schedule == 2) {
				autoElevator(1500);
			}else if(schedule == 3) {
				driveStraight(60, getDistance(), -90, true, 5);
			}else if(schedule == 4) {
				autoIntake();
			}else {
				myRobot.setSafetyEnabled(true);
			}
		}
	}	

	/**
	 * <b>Field Managment System Auto - left Side</b>
	 * <br> Gets gama data string for first route.
	 * <br> Drives straight to the side of the switch then turns into the switch.
	 */
	public void leftSide() {
		SmartDashboard.putNumber("Angle", gyroAngle);
		if(gameData.charAt(0) == 'L') { //left auto
			if(schedule == 0){
				driveStraight(400, getDistance(), 0, false, 0);	
			}else if(schedule == 1){
				turn(90, false);		
			}else if(schedule == 2) {
				autoElevator(1500);
			}else if(schedule == 3) {		
				driveStraight(60, getDistance(), 90, true, 4);
			}else if(schedule == 4){				
				autoIntake();
			}else {
				myRobot.setSafetyEnabled(true);
			}			
		}else if(gameData.charAt(0) == 'R'){
			if(schedule == 0){
				driveStraight(550, getDistance(), 0, false, 0);		
			}else if(schedule == 1) {
				turn(90, false);
			}else if(schedule == 2) {
				driveStraight(585, getDistance(), 90, false, 0);
			}else if(schedule == 3) {
				turn(180, false);
			}else if(schedule == 4) {	
				driveStraight(123, getDistance(), 180, false, 0);
			}else if(schedule == 5){
				turn(-90, false);
			}else if(schedule == 6) {
				autoElevator(1500);
			}else if(schedule == 7) {
				driveStraight(60, getDistance(), -90, true, 5);
			}else if(schedule == 8) {
				autoIntake();
			}else {
				myRobot.setSafetyEnabled(true);
			}
		}
	}
	
	/**
	 * <b> Straight Autonomous turn </b>
	 * <br> Drives in straight line from starting position
	 */
	public void straight() {
		if(schedule == 0) {
			driveStraight(420, getDistance(), 0, false, 0);
		}else {
			myRobot.setSafetyEnabled(true);
		}
	}
	
	/**
	 * <b> Auto Elevator </b>
	 * <br> Auto elevator lifts to 1500 ticks
	 */
	public void autoElevator(int position) {
		if(toggle) {
			elevator.set(ControlMode.Position, -position);
			toggle = false;
		}else {
			schedule++;	
		}
	}
	
	/**
	 * <b> Auto Intake </b>
	 * <br>Auto, runs intake and lifts 
	 * @param out - true: out, false: in
	 */
	public void autoIntake() {
			leftIntake.set(1);
			rightIntake.set(1);
			Timer.delay(3);
			leftIntake.set(0);
			rightIntake.set(0);
			schedule++;
	}
		
	/**
	 * <b>Turn</b>
	 * <br>This method controls turning in autonomous. The turn is relative to your starting position.
	 * <br> This gets the current angle from the gyro and calculates the difference from the target 
	 * position and the current angle.
	 * @param target	int: Negative - left, Positive - right
	 * @param wiggle	boolean: True - timer, False - no timer
	 */
	public void turn(int target, boolean wiggle){ 
		SmartDashboard.putNumber("Angle of Drive Train", gyro.getAngle());
		double Kp; //your porportional constant 
		if(wiggle){ //correction constant
			Kp = 0.04;
		}else{ //without correction for rough turn
			Kp = 0.025;
		}
		double defaultSpeed = 0.3; //default turn speed
		if(!reached) { //when target has not been reached
			gyroAngle = gyro.getAngle();
			error = (target - gyroAngle); //calculate error between target and current angle			
			speed = (Kp * error); 
			if (speed > defaultSpeed){
				speed = defaultSpeed;
			}else if (speed < -defaultSpeed){
				speed = - defaultSpeed;
			}
			//if the error is only 2 degrees
			if(error <= 6.5 && error >= -6.5 ){				
				if(!wiggle){ //without correction, rough turn
					reached = true;				
				}else{ //with correction, used at end of a drive 
					if(timeStart) { //starts the timer
						previous = Timer.getFPGATimestamp();
						timeStart = false;
					}	
				//correction takes 2.5 seconds. Calculates whether the target is reached
				if(((Timer.getFPGATimestamp()- previous) >= 2.5) && !timeStart) { 
					reached = true;
					}				
				}
			}
			//sets speed
			FLMotor.set(-speed);
			FRMotor.set(speed);
		}else { //once the target has been reached, stops motor, resets encoder, time and conditions
			FLMotor.set(0);
			FRMotor.set(0);
			encoder.reset();
			previous = 0.0;
			reached = false;
			timeStart = true;
			schedule++; ///scheduler is incremented by one	
		}
	}
		
	/**
	 * <b> Drive Straight </b>
	 * <p> Driving straight, runs the robot to its target distance by calling on the encoder method getDistance(), 
	 * and drives in the target angle, direction. This direction is  relative to the starting postion and angle reached
	 * by the turn method if called after turn method or 0 angle from start. 
	 * @param target - the distance intended to reach
	 * @param distance - the distance currently at, calls on getDistance() method
	 * @param direction - the angle currently driving on relative to the starting position.
	 * @param timeOut - If a timeout function is wanted
	 * @param time - In seconds, for timeout functions
	 */
	public void driveStraight(int target, double distance, double direction, boolean timeOut, int time) {
		//RUN STRAIGHT
		double leftSpeed = 0;
		double rightSpeed = 0;
		double Kp = 0.02;
		double Ki = 0.0002;
		double angle = gyro.getAngle();
		double adjusted = (angle-direction)*Kp;	
		//dashboard inputs
		SmartDashboard.putNumber("Adjusted", adjusted);
		SmartDashboard.putNumber("Angle", angle);
		SmartDashboard.putNumber("IntgralAdjusted", integralAdjusted_driveStraight);
		SmartDashboard.putNumber("Left", leftSpeed);
		SmartDashboard.putNumber("Right", rightSpeed);		
		//if the encoder distance tracked is still smaller than our tracked
		SmartDashboard.putBoolean("Expire", expire);
		if(target >= distance && !expire){
			integralAngle_driveStraight = integralAngle_driveStraight + (angle-direction);
			if (integralAngle_driveStraight > 10) {
				integralAngle_driveStraight = 10;
			}
			else if (integralAngle_driveStraight < -10) {
				integralAngle_driveStraight = -10;			
				}
			integralAdjusted_driveStraight = integralAngle_driveStraight*Ki;
			leftSpeed = 0.3 - adjusted - integralAdjusted_driveStraight;		// + adjusted;
			rightSpeed = -0.3 - adjusted - integralAdjusted_driveStraight;	//-1*(0.3 - adjusted);
			FLMotor.set(-leftSpeed);
			FRMotor.set(rightSpeed);
			if(timeOut) {
				if(timeStart) { //starts the timer
					previous = Timer.getFPGATimestamp();
					timeStart = false;
				}	
				//correction takes 2.5 seconds. Calculates whether the target is reached
				if(((Timer.getFPGATimestamp() - previous) >= time) && !timeStart) { 
					expire = true;
				}	
			}
		}else{
			timeStart = true;
			FLMotor.set(0.0);
			FRMotor.set(0.0);
			encoder.reset();
			integralAdjusted_driveStraight = 0;
			integralAngle_driveStraight = 0;
			schedule++;
		}
	}
	
	/**
	 * <b> Encoder Distance </b>
	 * <p> getDistance() computes the distance travelled by measuring
	 * the encoder ticks and calcultes 3 different units. <p>
	 * inches, centimeters and meters.
	 * @return distance - returns distance in centimeters
	 */
	public double getDistance() {
		count = (encoder.get())/4;
		double dpr = (((Math.PI)*6.34)/90);//distance per revolution (circumfere)/90 <- where 90 is the pulse/rev
		double inch = count*dpr;//18.84 = dpr		
		double cm = count*(dpr*2.54); //dpr - > 0.5319 = circumference(diameter*pi)/90 (pulse/rotation) * inchesToCm
		double meter = cm/100;
		SmartDashboard.putNumber("Count in inches", inch);
		SmartDashboard.putNumber("Count in Cm", cm);		
		SmartDashboard.putNumber("Count in m", meter);	
		return cm;
	}
	
	/**
	 * <b> <i>Intake Motor</i></b>
	 * <br> <b> Intake </b> - Right Trigger 
	 * <br> <b> Reverse </b> - Left Trigger
	 */
	public void intake(){
		//Axis 2 = left trigger
		if(joystickTwo.getRawAxis(2) > 0.5 && joystickTwo.getRawAxis(3) <= 0.5) { //Left
			leftIntake.set(1);
			rightIntake.set(1);
			
		//Axis 3 = left trigger	
		}else if(joystickTwo.getRawAxis(3) > 0.5 && joystickTwo.getRawAxis(2) <= 0.5) { //Right
			leftIntake.set(-1);
			rightIntake.set(-1);
			
		}else {
			leftIntake.set(0.0);
			rightIntake.set(0.0);
			}
	}
	
	/**
	 * <b> <i>Climber Motor</i></b>
	 * <br> <b> Up </b> - Right analog stick up, y-axis
	 * <br> <b> Down </b> - Right analog stick down, y-axis
	 * <br> Scale of 21 ticks per inch
	 */
	public void elevator() {
		//Scaling by 21. Divide ticks by 21 to get distance
		if(joystickTwo.getRawAxis(1) > 0.5) {//left analog stick, forward		
			elevator.set(1);
		}else if(joystickTwo.getRawAxis(1) < -0.5) {//left analog stick, reverse
			elevator.set(-0.7);
		/*}else if(joystickTwo.getRawButton(1) && !joystickTwo.getRawButton(2) && !joystickTwo.getRawButton(3) && !joystickTwo.getRawButton(4)) {//Button A: Ground
			elevator.set(ControlMode.Position, 0);
		}else if(joystickTwo.getRawButton(3) && !joystickTwo.getRawButton(1) && !joystickTwo.getRawButton(2) && !joystickTwo.getRawButton(4)) {//Button X: Portal
			elevator.set(ControlMode.Position, 420);
		}else if(joystickTwo.getRawButton(2) && !joystickTwo.getRawButton(1) && !joystickTwo.getRawButton(3) && !joystickTwo.getRawButton(4)) {//Button B: Switch
			elevator.set(ControlMode.Position, 800);
		}else if(joystickTwo.getRawButton(4) && !joystickTwo.getRawButton(1)  && !joystickTwo.getRawButton(2) && !joystickTwo.getRawButton(3)) {//Button Y: Exchange
			elevator.set(ControlMode.Position, 40);*/			
		}else {
			elevator.set(0);
		}			
	}
	
	/**
	 * <b> Climber </b>
	 * <br> Climber, moves at fulls speed and half joystick throttle. Use right analog stick.
	 */
	public void climber() {
		if(joystickTwo.getRawAxis(5) > 0.5) { //Right analog stick, reverse
			climb.set(-1);
		}else if(joystickTwo.getRawAxis(5) < -0.5) { //Left analog stick, forward
			climb.set(1);
		}else {
			climb.set(0.0);
			}		
		}
	
	/**
	 * <b> Drive train </b>
	 * <br>Arcade drive train, uses left analog stick y-axis, right analog stick for rotational driving.
 	 */
	public void drive() {
		myRobot.arcadeDrive(-joystickOne.getRawAxis(4), joystickOne.getRawAxis(1), true);
	}
	
	/**
	 * This function is called periodically during operator control.
	 */
	@Override
	public void teleopPeriodic() {
		SmartDashboard.putNumber("Distance (cm): ", getDistance());
		SmartDashboard.putNumber("Angle of Drive Train", gyro.getAngle());
		SmartDashboard.putNumber("Sensor Quadrature Position: ", elevator.getSensorCollection().getQuadraturePosition());
		
		drive();
		climber();
		elevator();
		intake();
	}

	/**
	 * This function is called periodically during test mode.
	 */
	@Override
	public void testPeriodic() {
	}
}
