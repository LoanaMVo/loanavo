import java.util.Scanner;
import java.util.Random;

/*
 * Play game class holds all game methods and excution of the game.
 * Uses queue and stack class in the simulation where a user plays
 * hot potato with a number of players. Winner and ranks are declared.
 */
public class PlayGame {
	static Queue q = new Queue();
	static Stack stack = new Stack();
	static Random rand = new Random();
	static Scanner input = new Scanner(System.in);

	/*
	 * Main method is used to excute the game and its methods. Loops the get
	 * name method and enqueues it into the list by first asking the user to
	 * input an integer as the amount of players participating in the game.
	 * After list is full, loops the game method where the potato is enqueued
	 * and dequeued repeatedly in a loop by a random increment of passes.
	 */
	public static void main(String[] args) {
		int play = 0;
		boolean game = true;
		boolean newName = true;
		while (game == true)
			switch (play) {
			case 0:// game
				System.out.println("Welcome to the Hot Potato Game!!!");
				if (newName) {
					int maxSize = players();
					while (q.size() < maxSize) {// ask for names
						q.enqueue(getName());// enqueues the names
					}
				}
				while (!q.isEmpty()) {
					passes();// calls for potato passing method
				}
				ranks();// dequeues the stack and prints out the ranks
			case 1:// when game is done, ask if user wants to play again
				System.out.println("Would you like to play again? (0 = yes, any other number = no)");
				int state = askNumber();
				if (state == 0) {
					System.out.println("Would you like to use new names? (0 = yes, any other number = no)");
					state = askNumber();
					if (state == 0) {
						newName = true;
						int size = q.size();
						for(int i =0; i < size; i++){
							q.dequeue();
						}
					} else {
						newName = false;
					}
					break;
				}
			default:// if player doesnt want to play
				System.out.println("Thank you for playing the game!");
				game = false;
				break;
			}
	}

	/*
	 * Method asks for an integer and catches any errors using try and catch.
	 * Breaks out of try if the number is a real integer, else repeats until a
	 * valid number is entered. If a negative number is found, it throws in an
	 * error.
	 */
	public static int askNumber() {
		int num = 0;
		while (true)
			try {
				num = Integer.parseInt(input.nextLine());
				if (num < 0) {
					throw new IllegalArgumentException();
				}
				break;
			} catch (Exception nfe) {
				System.out.println("Try again. Enter in a number.");
			}
		return num;
	}

	/*
	 * Asks for user input for amount of players and returns the number as an
	 * int.
	 */
	public static int players() {
		System.out.println("Type in the number of players.");
		return askNumber();
	}

	/*
	 * Asks for user input for names of the people playing the game. Returns as
	 * a string.
	 */
	public static String getName() {
		System.out.println("Type in the names of the players.");
		String name = input.nextLine();
		return name;
	}

	/*
	 * Method dequeues person at the back and enqueues them to the front of the
	 * list by calling on methods from Queue class. Prints out the name of the
	 * people that caught the potato and loses the game.
	 */
	public static void passes() {
		String dqName = null;
		int passNum = rand.nextInt(10) + 1;
		for (int i = 0; i < passNum; i++) {// loops for random amount of times
			if (q.size() != 1) {
				dqName = q.dequeue();// dequeues the person
				q.enqueue(dqName);// enqueues the person back
				System.out.println(q.peek() + " has the potato!");
				sleep();
			} else {
				break;
			}
		}
		String firstName = q.peek();// looks at person with potato
		if (q.size() == 1) {// if there is one person left, declare winnter
							// before dequeuing them from list
			sleep();
			System.out.println(firstName + " is the winner!");
		} else if (q.size() > 0) {// if size is less than 0, print who is out
									// and dequeued.
			sleep();
			System.out.println("Oh no, " + firstName + " has caught the hot potato and is out!");
			sleep();
		}
		stack.enqueue(firstName);
		q.dequeue(); // remove person with potato
	}

	/*
	 * Method dequeues items from the stack and print out the rankings of the
	 * players.
	 */
	public static void ranks() {
		int size = stack.size();
		System.out.println();
		sleep();
		System.out.println("Ranks:");
		for (int i = 0; i < size; i++) {
			sleep();
			q.enqueue(stack.peek());
			System.out.println((i + 1) + ". " + stack.peek());
			stack.dequeue();
		}
		sleep();
	}

	/*
	 * Sleep method delays the program for 500 miliseconds
	 */
	public static void sleep() {
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
