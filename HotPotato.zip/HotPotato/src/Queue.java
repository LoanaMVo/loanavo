import java.util.ArrayList;

public class Queue{
	//front of the list is the highest index, back of the list is at index 0
	private static ArrayList<String> myQ;

	/*
	 * Creates myQ object
	 */
	public Queue() {
		myQ = new ArrayList<String>();
	}

	/*
	 * This method enqueues the item to the back of the list at index 0.
	 */
	public void enqueue(String item) {
		myQ.add(0, item);
	}

	/*
	 * This method dequeues and removes the item from the front of the list
	 * at the index of the max number and returns it as a string.
	 */
	public String dequeue() {
		return myQ.remove(myQ.size() - 1);
	}
	
	/*
	 * This method returns the size of the list.
	 */
	public int size() {
		return myQ.size();
	}

	/*
	 * This method checks if the method is empty or not and returns a boolean value
	 * as true if the method is empty and false if it is not empty.
	 */
	public boolean isEmpty() {
		if (myQ.isEmpty()) {
			return true;

		} else {
			return false;
		}
	}

	/*
	 * This method checks the front of the list by getting the item at the
	 * highest index of the list. 
	 */
	public String peek() {
		String name = myQ.get(myQ.size()-1);
		return name;
	}
}
