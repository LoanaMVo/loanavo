import java.util.ArrayList;

public class Stack{
	private static ArrayList<String> myStack;//creates a myStack array list
	
	/*
	 * Creates stack object
	 */
	public Stack(){
		myStack = new ArrayList<String>();
	}
	
	/*
	 * Method adds string item to the back of the list
	 */
	public void enqueue(String item){
		myStack.add(0, item);
	}
	
	/*
	 * Method dequeues and removes item from the back of list, 
	 * item is last in but first out.
	 */
	public void dequeue(){
		myStack.remove(0);
	}
	/*
	 * Method looks at the first item in the stack
	 */
	public String peek(){
		return myStack.get(0);
	}
	
	/*
	 * Looks at size of the stack
	 */
	public int size() {
		return myStack.size();
	}	
}

