Class: ICS3U
By: Loana Vo

Game finished: 2017-06-17

Bugs:
Slow mouse click, works well on touch screen.
Corner ground blocks can be jumped through. 