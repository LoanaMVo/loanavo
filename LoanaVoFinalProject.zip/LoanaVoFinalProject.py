# -*- coding: cp1252 -*-
###############################################################################
#Loana's Final Project                                                        #
#By: Loana Vo                                                                 #  
#2017-05-25                                                                   #
#Single player, stage based game                                              #
#Refrences: year-month-date                                                   #
###############################################################################
import pygame, sys, time, random, inputbox
from pygame.locals import *
###############################################################################
pygame.init()
pygame.display.set_caption("game platform")
###############################################################################
width = 1200
height = 600
screen = pygame.display.set_mode((width, height))
screenRect = pygame.Rect(0,0,1200,600)
###############################################################################
clock = pygame.time.Clock()
FPS = 300
###############################################################################
levelTwoImg = pygame.image.load("Images/MapImages/LevelTwo/levelTwo.png")
backgroundCredits = pygame.image.load("Images/MenuImages/credit.png")
winImgTwo = pygame.image.load("Images/MapImages/LevelTwo/levelTwo.png")
ground2 = pygame.image.load("Images/MapImages/LevelTwo/ground.png")
wallImg2 = pygame.image.load("Images/MapImages/LevelTwo/wall.png")
backgroundHow = pygame.image.load("Images/MenuImages/howToPlay.png")
gameOverB = pygame.image.load("Images/MenuImages/gameOver.png")
winBackground = pygame.image.load("Images/MenuImages/win.png")
winImgOne = pygame.image.load("Images/Sprites/apple.png")
winImgTwo = pygame.image.load("Images/Sprites/star.png")
winImgThree = pygame.image.load("Images/Sprites/whale.png")
menuScreen = pygame.image.load("Images/MenuImages/menuImg.png")
background =  pygame.image.load("Images/MenuImages/background.png")
wallImg = pygame.image.load("Images/MapImages/LevelOne/wall.png")
ground = pygame.image.load("Images/MapImages/LevelOne/ground.png")
levelOneImg = pygame.image.load("Images/MapImages/LevelOne/levelOne.png")
charRight = pygame.image.load("Images/Sprites/characterRight.png")
charLeft = pygame.image.load("Images/Sprites/characterLeft.png")
heartImg = pygame.image.load("Images/Sprites/charHeart.png")
ghostLeft = pygame.image.load("Images/Sprites/ghostLeft.png")
ghostRight = pygame.image.load("Images/Sprites/ghostRight.png")
halfOneImg = pygame.image.load("Images/Sprites/heartOne.png")
halfTwoImg = pygame.image.load("Images/Sprites/heartTwo.png")
orbOne = pygame.image.load("Images/Sprites/orbOne.png")
door = pygame.image.load("Images/MapImages/door0.gif")
winImg = pygame.image.load("Images/MapImages/door0.gif")
cursor = pygame.image.load("Images/MenuImages/star.png")
arrow = pygame.image.load("Images/MenuImages/Arrow.gif")
###############################################################################
mousePos = (0,0)
clicked = False
###############################################################################
fontFive = pygame.font.Font("Fonts/pixelBubble.TTF", 90)
fontSix = pygame.font.Font("Fonts/pixelBubble.TTF", 55)
fontSeven = pygame.font.Font("Fonts/pixelBubble.TTF", 20)
fontOne = pygame.font.Font("Fonts/pixelBubble.TTF", 30)
fontTwo = pygame.font.SysFont("Aharoni", 25)
fontThree = pygame.font.SysFont("Aharoni", 30)
fontFour = pygame.font.SysFont("Aharoni", 40)
font = [fontOne, fontTwo, fontThree, fontFour, fontFive, fontSix, fontSeven]
###############################################################################
#Colours
colour = [(0,0,0),(255,255,255),(29,27,49),(58,60,86),(79,81,101),(108,112,130),(255,245,80),(255,174,201),(255,0,0)]
screen.fill(colour[1])
###############################################################################
#clear
cx = 0
cy = 0
clears = []
#Ground
gx = 0
gy = 0
grounds = []
#sides
sx = 0
sy = 0
sides = []
#speed
dx = 0
dy = 0
#heart
hx = 0
hy = 0
livesList = [0,0,0,0,0]
lives = []
#enemy
ex = 0
ey = 0
enemys = []
enemySpeed = []
eSpeed = 5
#player
playerRect = pygame.Rect(5,500,50,50)
xSpeed = 15
ySpeed = -25
fall = 15
#movment
jump = False
right = True
left = False
collision = True
#bullets
bullets = []
bulletSpeed = 20
direction = 0
bulletInfo = ()
bx = playerRect.x
by = playerRect.y
###############################################################################
#counters
count = 0
countOne = 0
countTwo = 0
countThree = 0
countFour = 0
countFive = 0
countSix = 0
countSeven = 0
countEight = 0
#level stuff
win = False
gameOver = False
menu = True
playScreen = False
htpScreen = False
creditScreen = False
#level One
levelOne = False
levelTwo = False
levelThree = False
stageOne = False
stageTwo = False
stageThree = False
stageFour = False
stageFive = False
stageSix = False
one = False
two = False
three = False
four = False
five = False
six = False
#text
tx = 50
ty = 10
displayf = False
###############################################################################
#score
score = 0
###############################################################################
def mousePressed(event):
    global mousePos, clicked
    if event.type == pygame.MOUSEBUTTONDOWN:
        mousePos = pygame.mouse.get_pos()
        clicked = True
        
game = True
while game:
    while menu == True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mousePressed(event)
                
        #screen fill
        screen.fill(colour[0])
        screen.blit(menuScreen, (0,0))
        #title
        title = font[4].render("Explore",True,colour[3])
        titleRect = pygame.Rect(50,50,title.get_width(),title.get_height())
        screen.blit(title,(titleRect))
        #play
        play = font[5].render("Play",True,colour[4])
        playRect = pygame.Rect(50,titleRect.bottom+50,play.get_width(),play.get_height())
        screen.blit(play,(playRect))
        #how to play
        how = font[5].render("How",True,colour[5])
        howRect = pygame.Rect(50,playRect.bottom+50,how.get_width(),how.get_height())
        screen.blit(how,(howRect))
        
        to = font[5].render("To",True,colour[5])
        toRect = pygame.Rect(howRect.right+30,playRect.bottom+50,to.get_width(),to.get_height())
        screen.blit(to,(toRect))
        
        p = font[5].render("Play",True,colour[5])
        pRect = pygame.Rect(toRect.right+30,playRect.bottom+50,p.get_width(),p.get_height())
        screen.blit(p,(pRect))

        howToPlayRect = pygame.Rect(howRect.left,howRect.top,pRect.right-howRect.left,how.get_height())
        
        #credits
        credit = font[5].render("Credits",True,colour[5])
        creditRect = pygame.Rect(50,howRect.bottom+50,credit.get_width(),credit.get_height())
        screen.blit(credit,(creditRect))

        pygame.mouse.set_visible(False)
        mousePos = pygame.mouse.get_pos()
        screen.blit(cursor,(mousePos))

        if (playRect.collidepoint(mousePos) and clicked == True):
            playScreen = True
            menu = False
            clicked = False
        elif (howToPlayRect.collidepoint(mousePos) and clicked == True):
            htpScreen =  True
            menu = False
            clicked = False
        elif (creditRect.collidepoint(mousePos) and clicked == True):
            creditScreen = True
            menu = False
            clicked = False
        
        pygame.display.flip()
        pygame.display.update()
        clock.tick(FPS)
        
    #level selection
    while playScreen == True:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                mousePressed(event)
            elif event.type == pygame.QUIT:
                game = False
        screen.fill(colour[4])
        screen.blit(background,(0,0))
        #back
        backRect = pygame.Rect(50,500,78,50)
        screen.blit(arrow,(backRect))
        mousePos = pygame.mouse.get_pos()
        screen.blit(cursor,(mousePos))
        #selections
        oneRect = pygame.Rect(350,50,500,133)
        twoRect = pygame.Rect(350,oneRect.bottom+50,500,134)

        pygame.draw.rect(screen,colour[0],oneRect)
        pygame.draw.rect(screen,colour[0],twoRect)

 
        oneText = font[0].render("Level One",True,colour[1])
        twoText = font[0].render("Level Two",True,colour[1])
      
        screen.blit(oneText,(oneRect.centerx-oneText.get_width()/2,oneRect.centery-oneText.get_height()/2))
        screen.blit(twoText,(twoRect.centerx-twoText.get_width()/2,twoRect.centery-twoText.get_height()/2))

        if (backRect.collidepoint(mousePos) and clicked == True):
            playScreen = False
            menu = True
            clicked = False
        elif (oneRect.collidepoint(mousePos) and clicked == True):
            playScreen = False
            levelOne = True
            stageOne = True
            clicked = False
            pygame.mouse.set_visible(True)
        elif (twoRect.collidepoint(mousePos) and clicked == True):
            playScreen = False
            levelTwo = True
            stageFour = True
            clicked = False
            pygame.mouse.set_visible(True)

    
        pygame.display.update()
        clock.tick(FPS)
        
    #how to play        
    while htpScreen == True:
        screen.fill(colour[5])
        screen.blit(backgroundHow,(0,0))

        #back
        backRect = pygame.Rect(0,550,78,50)
        screen.blit(arrow,(backRect))
        mousePos = pygame.mouse.get_pos()
        screen.blit(cursor,(mousePos))
        
        if (backRect.collidepoint(mousePos) and clicked == True):
            htpScreen = False
            menu = True
            clicked = False

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                mousePressed(event)
            elif event.type == pygame.QUIT:
                game = False
                
        pygame.display.update()
        clock.tick(FPS)
        
    while creditScreen == True:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                mousePressed(event)
            elif event.type == pygame.QUIT:
                game = False
        screen.fill(colour[0])
        screen.blit(backgroundCredits,(0,0))
        
        #back
        backRect = pygame.Rect(0,550,78,50)
        screen.blit(arrow,(backRect))
        mousePos = pygame.mouse.get_pos()
        screen.blit(cursor,(mousePos))
        #credit
        if (backRect.collidepoint(mousePos) and clicked == True):
            creditScreen = False
            menu = True
            clicked = False
        pygame.display.update()
        clock.tick(FPS)
        
    while levelOne == True:            
        while stageOne == True:
            level1 = [
            "SSSSSSSSSSSSSSSSSSSSSSSS",
            "S        C       E     S",
            "S         GGGGGGGGGGGGGS",
            "S    GGG               S",
            "S        GGGG          S",
            "S      GGG             S",
            "S             GGG      S",
            "      GGGGGG     C   E S",
            "            GGGG  GGGGGS",
            "     G GG         GGGGGS",
            "   GGGGGGGGGGGGGGGGGGGGS",
            "GGGGGGGGGGGGGGGGGGGGGGGG"
            ]
            grounds = []
            sides = []
            enemys = []
            enemySpeed = []
            gx = 0
            gy = 0
            sx = 0
            sy = 0
            ex = 0
            ey = 0
            cx = 0
            cy = 0
            for row in level1:
                for col in row:
                    if col == "G":
                        groundRect = pygame.Rect(gx,gy,50,50)
                        grounds.append(groundRect)
                    elif col == "S":
                        sideRect = pygame.Rect(sx,sy,50,50)
                        sides.append(sideRect)
                    elif col == "E":
                        enemyRect = pygame.Rect(ex,ey,50,50)
                        enemys.append(enemyRect)
                        enemySpeed.append(eSpeed)
                    elif col == "C":
                        clearRect = pygame.Rect(cx,cy,50,50)
                        clears.append(clearRect)
                    gx = gx + 50
                    sx = sx + 50
                    ex = ex + 50
                    cx = cx + 50
                gy = gy + 50
                gx = 0
                sy = sy + 50
                sx = 0
                ey = ey + 50
                ex = 0
                cx = 0
                cy = cy + 50
            hx = 0
            hy = 0
            livesList = [1,1,1,1,1]
            for i in livesList:
                heartRect = pygame.Rect(hx,hy,30,26)
                lives.append(heartRect)
                hx = hx + 32    
            dx = 0
            doorRect = pygame.Rect(1100,31,50,100)
            playerRect.bottom = 550
            playerRect.left = 0
            one = True
            two = False
            three = False
            four = False
            five = False
            six = False
            
            stageOne = False
            score = 0
        
        while stageTwo == True:
            level2 = [
            "SGGGGGGGGGGGGGGGGGGGGGGG",                   
            "         G    C   E    S", 
            "SGGGGGG  G     GGGGGG  S",  
            "SC  E    GGGG       G  S", 
            "S GGGGGGGG        GGG  S", 
            "S            G      G  S", 
            "S              GGG  G  S",             
            "S     C     E       G  S",  
            "S      GGGGGGGGGGGGGG  S",             
            "S    GGGGGGGGGGGGGGGG  S",
            "S E GGGGGGGGGGGGGGGGG  S",          
            "GGGGGGGGGGGGGGGGGGGGGGGG"
            ]
            grounds = []
            sides = []
            enemys = []
            enemySpeed = []
            gx = 0
            gy = 0
            sx = 0
            sy = 0
            ex = 0
            ey = 0
            cx = 0
            cy = 0
            playerRect.bottom = 100
            playerRect.left = 50
            for row in level2: 
                for col in row:
                    if col == "G":
                        groundRect = pygame.Rect(gx,gy,50,50)
                        grounds.append(groundRect)
                    elif col == "S":
                        sideRect = pygame.Rect(sx,sy,50,50)
                        sides.append(sideRect)
                    elif col == "E":
                        enemyRect = pygame.Rect(ex,ey,50,50)
                        enemys.append(enemyRect)
                        enemySpeed.append(eSpeed)
                    elif col == "C":
                        clearRect = pygame.Rect(cx,cy,50,50)
                        clears.append(clearRect)
                    gx = gx + 50
                    sx = sx + 50
                    ex = ex + 50
                    cx = cx + 50
                gy = gy + 50
                gx = 0
                sy = sy + 50
                sx = 0
                ey = ey + 50
                ex = 0
                cx = 0
                cy = cy + 50
            doorRect = pygame.Rect(1100,481,50,100)
            one = False
            two = True
            three = False
            four = False
            five = False
            six = False

            stageTwo = False
            
        while stageThree == True:
            level3 = [
            "                       S",
            "                    GGGS",
            "                       S",  
            "                 GGG   S",
            "           C  E    E   S", 
            "            GGGGGGGGGGGS",
            "      GGG              S",  
            "C              E  C    S",   
            "        E C   GGGG     S",
            "GGGGGGGGGG             S",
            "GGGGGGGGGG             S",
            "GGGGGGGGGG             S"
            ]
            grounds = []
            sides = []
            enemys = []
            enemySpeed = []
            gx = 0
            gy = 0
            sx = 0
            sy = 0
            ex = 0
            ey = 0
            cx = 0
            cy = 0
            playerRect.bottom = 350
            playerRect.left = 50
            doorRect = pygame.Rect(-100,-100,50,100)
            for row in level3: 
                for col in row:
                    if col == "G":
                        groundRect = pygame.Rect(gx,gy,50,50)
                        grounds.append(groundRect)
                    elif col == "S":
                        sideRect = pygame.Rect(sx,sy,50,50)
                        sides.append(sideRect)
                    elif col == "E":
                        enemyRect = pygame.Rect(ex,ey,50,50)
                        enemys.append(enemyRect)
                        enemySpeed.append(eSpeed)
                    elif col == "C":
                        clearRect = pygame.Rect(cx,cy,50,50)
                        clears.append(clearRect)
                    gx = gx + 50
                    sx = sx + 50
                    ex = ex + 50
                    cx = cx + 50
                gy = gy + 50
                gx = 0
                sy = sy + 50
                sx = 0
                ey = ey + 50
                ex = 0
                cx = 0
                cy = cy + 50
            winRect = pygame.Rect(1100,0,50,50)
            one = False
            two = False
            three = True
            four = False
            five = False
            six = False
            stageThree = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game = False
            #when key is pressed
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_a:
                    dx = -xSpeed
                    left = True
                    right = False
                elif event.key == pygame.K_d:
                    dx = xSpeed
                    right = True
                    left = False
                elif event.key == pygame.K_w:
                    for groundBlock in grounds:
                        if playerRect.bottom == groundBlock.top:
                            dy = ySpeed
                            jump = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                if right == True:
                    if bulletSpeed < 0:
                        bulletSpeed = -bulletSpeed
                    else:
                        bulletSpeed = bulletSpeed
                    bx = playerRect.right
                elif left == True:
                    if bulletSpeed > 0:
                        bulletSpeed = -bulletSpeed
                    else:
                        bulletSpeed = bulletSpeed
                    bx = playerRect.left
                by = playerRect.centery
                bulletRect = pygame.Rect(bx,by,15,15)
                bulletInfo = (bulletRect,bulletSpeed)
                bullets.append(bulletInfo)
                
            #when key is up
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    dx = 0
                elif event.key == pygame.K_d:
                    dx = 0
        screen.blit(levelOneImg,(0,0))
        #BLITTING ALL FOR LOOPS
        #blit images of ground and sides
        for g in grounds:
            screen.blit(ground,(g))
            #Wall side
        for side in sides:
            screen.blit(wallImg, (side))
        #lives box
        for heart in lives:
            screen.blit(heartImg,(heart))
        #enemy
        count = 0
        for i in enemys:
            if enemySpeed[count]> 0:
                screen.blit(ghostRight,(i))
            elif enemySpeed[count] < 0:
                screen.blit(ghostLeft,(i))
            i.x += enemySpeed[count]
            count = count + 1
        #bullet speeds
        for bullet in bullets:
            screen.blit(orbOne,(bullet[0]))
            bullet[0].x += bullet[1]
        #CHARACTER    
        #movment of y and x position of character
        playerRect.x += dx
        playerRect.y += dy

        #win and flag obtacles
        screen.blit(door, (doorRect))
        #screen.blit(winImg,(winRect))
        #COLLISION
        #end of map
        if playerRect.left < screenRect.left:
            playerRect.left = screenRect.left
        elif playerRect.right > screenRect.right:
            playerRect.right = screenRect.right
        elif playerRect.colliderect(screenRect):
            if playerRect.bottom > screenRect.bottom and len(lives)is not 0:
                lives.pop(len(lives)-1)
                playerRect.y += -100
                if len(lives) == 0:
                    gameOver = True
                    levelOne = False
                    levelTwo = False
                    
        #JUMPING
        if jump == True:
            for groundBlock in grounds:
                #vertex of jump    
                if playerRect.colliderect(groundBlock):
                    if ((groundBlock.top-playerRect.bottom) >= 125):
                        dy = -dy     
                #ground landed on for bottom left corner
                if groundBlock.collidepoint(playerRect.left+1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                       dy = 0
                       jump = False
                #ground landed on for bottom right corner
                if groundBlock.collidepoint(playerRect.right-1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                       dy = 0
                       jump = False                
                       
            #the underside of ground block           
            for groundBlock in grounds:
                #if collides with players top left corner
                if dx > 0:
                    if groundBlock.collidepoint(playerRect.left+1,playerRect.top):
                        playerRect.top = groundBlock.bottom
                        dy = 0
                #if collides with players top right corner
                elif dx < 0:
                    if groundBlock.collidepoint(playerRect.right-1,playerRect.top):
                        playerRect.top = groundBlock.bottom
                        dy = 0
                elif dx == 0:
                    if groundBlock.collidepoint(playerRect.right-1,playerRect.top) or groundBlock.collidepoint(playerRect.left+1,playerRect.top):
                        playerRect.top = groundBlock.bottom
                        dy = 0

            for s in sides:
                #if collides with players top left corner
                if s.collidepoint(playerRect.left,playerRect.top):
                    playerRect.top = s.bottom
                    dy = 0
                #if collides with players top right corner
                elif s.collidepoint(playerRect.right,playerRect.top):
                    playerRect.top = s.bottom
                    dy = 0
                    
        #NOT JUMPING
        #RIGHT
        if jump == False:
            playerRect.y += fall
            for groundBlock in grounds:
                #if player collides with top ground wall
                #playerys bottom left corner    
                if groundBlock.collidepoint(playerRect.left+1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                #players bottom right right corner
                elif groundBlock.collidepoint(playerRect.right-1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                #colliding with sides
                if playerRect.colliderect(groundBlock):
                    if dx > 0: # walking to the right
                        if playerRect.right > groundBlock.left: #colliding left side of wall
                            playerRect.right = groundBlock.left  
                            dx = 0
                    elif dx < 0: #walking to the left
                        if playerRect.left < groundBlock.right: #colliding right side of wall
                            playerRect.left = groundBlock.right  
                            dx = 0
        #arching of jump
        if jump == True:
            dy = dy + 3
                
        #SIDE WALLS
        for sideCollide in sides:
            #player
            #colliding with sides
            if playerRect.colliderect(sideCollide):
                if dx > 0: # walking to the right
                    if playerRect.right > sideCollide.left: #colliding left side of wall
                        playerRect.right = sideCollide.left  
                        dx = 0
                elif dx < 0: #walking to the left
                    if playerRect.left < sideCollide.right: #colliding right side of wall
                        playerRect.left = sideCollide.right  
                        dx = 0
            #enemy
            countOne = 0
            for enemy in enemys:
                #left side of wall
                if enemy.colliderect(sideCollide):
                    enemySpeed[countOne] = -enemySpeed[countOne]
                countOne += 1

            #bullet collision
            countTwo = 0
            for b in bullets:
                if b[0].colliderect(sideCollide):
                    if b[1] > 0:#to the right
                        if b[0].right > sideCollide.left:
                            b[0].right = sideCollide.left
                            bullets.pop(countTwo)
                    elif b[1] < 0: #to the left
                        if b[0].left < sideCollide.right:
                            b[0].left = sideCollide.right
                            bullets.pop(countTwo)
                countTwo += 1       

        #bullet to wall collision    
        for groundBlock in grounds:
            countThree = 0
            for b in bullets:
                if b[0].colliderect(groundBlock):
                    if b[1] > 0:
                        if b[0].right > groundBlock.left:
                            b[0].right = groundBlock.left
                            bullets.pop(countThree)
                    elif b[1] < 0:
                        if b[0].left < groundBlock.right:
                            b[0].left = groundBlock.right
                            bullets.pop(countThree)
                countThree += 1    
        #enemy
        #if walking to the right (positive direction)
        countFive = 0
        for enemy in enemys:
            if playerRect.colliderect(enemy) and len(lives) is not 0:
                if dx > 0:
                    if playerRect.left < enemy.right:
                        length = len(lives)
                        lives.pop(length-1)
                        playerRect.x += -70
                        playerRect.y += -50
                elif dx < 0:
                    if playerRect.right > enemy.left:
                        length = len(lives)
                        lives.pop(length-1)
                        playerRect.x += 70
                        playerRect.y += -50                    
                else:
                    length = len(lives)
                    lives.pop(length-1)
                    playerRect.x += 100
                    playerRect.y += -50
                    
            if enemy.colliderect(doorRect):
                enemySpeed[countFive] = -enemySpeed[countFive]
                countFive += 1
            countFive = 0
            
        if len(lives) == 0 or len(lives)<0:
            levelOne = False
            levelTwo = False
        
            gameOver = True
            
        #enemy collision to bullets
        countEight = 0
        countFour = 0
        for enemy in enemys:
            for bullet in bullets:
                countFour = 0
                if bullet[0].colliderect(enemy):
                    bullets.pop(countFour)
                    enemys.pop(countEight)
                    score += 100
                countFour += 1
            countEight += 1           
            
        #enemy to clear
        for clear in clears:
            countSix = 0
            for enemy in enemys:
                if enemy.colliderect(clear):
                    enemySpeed[countSix]= -enemySpeed[countSix]
                countSix += 1
        #if enemy touches ground block
        for groundBlock in grounds:
            countSeven = 0
            for enemy in enemys:
                if enemy.colliderect(groundBlock):
                    if enemySpeed[countSeven] > 0:
                        if enemy.right > groundBlock.left:
                            enemySpeed[countSeven] = -enemySpeed[countSeven]    
                    elif enemySpeed[countSeven] < 0:
                        if enemy.left < groundBlock.right:
                            enemySpeed[countSeven] = -enemySpeed[countSeven]
                countSeven += 1
        #stages on door collision 
        if one == True:
            if playerRect.colliderect(doorRect):
                stageTwo = True
        elif two == True:
            if playerRect.colliderect(doorRect):
                stageThree = True
        elif three == True:
            screen.blit(winImgOne,(winRect))
            if playerRect.colliderect(winRect):
                levelOne = False
                win = True
        elif four == True:
            if playerRect.colliderect(doorRect):
                stageFive = True
        elif five == True:
            if playerRect.colliderect(doorRect):
                stageSix = True
        elif six == True:
            screen.blit(winImgTwo,(winRect))
            if playerRect.colliderect(winRect):
                levelTwo = False
                win = True
                
        scoreText = font[6].render(str(score),True,colour[1])
        screen.blit(scoreText,(165,2))
        #blit character
        if right == True:
            screen.blit(charRight, (playerRect))
        elif left == True:
            screen.blit(charLeft,(playerRect))
        pygame.display.flip()
        pygame.display.update()
        clock.tick(FPS)

    while gameOver == True:
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                mousePressed(event)
            elif event.type == pygame.QUIT:
                game = False
        screen.fill(colour[0])
        screen.blit(gameOverB,(0,0))
        winText = font[4].render("Game Over!",True,colour[1])
        winTextRect = pygame.Rect(width/2-winText.get_width()/2,100,winText.get_width(),winText.get_height())
        screen.blit(winText, (winTextRect))

        playAgain = font[0].render("Play Again",True,colour[6])
        playAgainRect =  pygame.Rect(winTextRect.left,winTextRect.bottom+30,playAgain.get_width(),playAgain.get_height())
        screen.blit(playAgain, (playAgainRect))

        menuText = font[0].render("Menu",True,colour[7])
        menuRect =  pygame.Rect(playAgainRect.right+10,winTextRect.bottom+30,menuText.get_width(),menuText.get_height())
        screen.blit(menuText, (menuRect))

        quitText = font[0].render("Quit",True,colour[8])
        quitRect =  pygame.Rect(menuRect.right+10,winTextRect.bottom+30,quitText.get_width(),quitText.get_height())
        screen.blit(quitText, (quitRect))

        if playAgainRect.collidepoint(mousePos) and clicked == True:
            gameOver = False
            clicked = False
            if one == True or two == True or three == True:
                levelOne = True
                stageOne = True
            elif four == True or five == True or six == True:
                levelTwo = True
                stageFour = True
                
        elif menuRect.collidepoint(mousePos) and clicked == True:
            gameOver = False
            menu = True
            clicked = False
            levelOne = False
            levelTwo = False
            levelThree = False
            stageOne = False
            stageTwo = False
            stageThree = False
            stageFour = False
            stageFive = False
            stageSix = False
            one = False
            two = False
            three = False
            four = False
            five = False
            six = False
        elif quitRect.collidepoint(mousePos) and clicked == True:
            pygame.quit()
            sys.exit()
        
        pygame.display.update()
        clock.tick(FPS)
    while levelTwo == True:            
        while stageFour == True:
            level1 = [
            "SSSSSSSSSSSSSSSSSSSSSSSS",
            "SSSSSSSSSSS            S",
            "SSSSSSSSSSSE    GGGGGGGS", 
            "SSSSSSSSSSSGG          S",
            "S             G        S",
            "S           C  E G     S",
            "S            GGGGG     S",
            "S            GGGGG     S",
            "S         G  GGGGG     S",
            "S     E  C   GGGGG     S",
            "    GGGGG    GGGGG     S",
            "GGGGGGGGG    GGGGG     G"
            ]
            grounds = []
            sides = []
            enemys = []
            enemySpeed = []
            gx = 0
            gy = 0
            sx = 0
            sy = 0
            ex = 0
            ey = 0
            cx = 0
            cy = 0
            for row in level1:
                for col in row:
                    if col == "G":
                        groundRect = pygame.Rect(gx,gy,50,50)
                        grounds.append(groundRect)
                    elif col == "S":
                        sideRect = pygame.Rect(sx,sy,50,50)
                        sides.append(sideRect)
                    elif col == "E":
                        enemyRect = pygame.Rect(ex,ey,50,50)
                        enemys.append(enemyRect)
                        enemySpeed.append(eSpeed)
                    elif col == "C":
                        clearRect = pygame.Rect(cx,cy,50,50)
                        clears.append(clearRect)
                    gx = gx + 50
                    sx = sx + 50
                    ex = ex + 50
                    cx = cx + 50
                gy = gy + 50
                gx = 0
                sy = sy + 50
                sx = 0
                ey = ey + 50
                ex = 0
                cx = 0
                cy = cy + 50
            hx = 0
            hy = 0
            livesList = [1,1,1,1,1]
            for i in livesList:
                heartRect = pygame.Rect(hx,hy,30,26)
                lives.append(heartRect)
                hx = hx + 32    
            dx = 0
            doorRect = pygame.Rect(1100,31,50,100)
            playerRect.bottom = 550
            playerRect.left = 0
            one = False
            two = False
            three = False
            four = True
            five = False
            six = False
            
            stageFour = False
            score = 0
        
        while stageFive == True:
            level2 = [
            "SGGGGGGGGGGGGGGGGGGGGGGG",                   
            "         G    C   E    S", 
            "SGGGGGG  G     GGGGGG  S",  
            "SC  E    GGGG       G  S", 
            "S GGGGGGGG        GGG  S", 
            "S            G      G  S", 
            "S              GGG  G  S",             
            "S     C     E       G  S",  
            "S      GGGGGGGGGGGGGG  S",             
            "S    GGGGGGGGGGGGGGGG  S",
            "S E GGGGGGGGGGGGGGGGG  S",          
            "GGGGGGGGGGGGGGGGGGGGGGGG"
            ]
            grounds = []
            sides = []
            enemys = []
            enemySpeed = []
            gx = 0
            gy = 0
            sx = 0
            sy = 0
            ex = 0
            ey = 0
            cx = 0
            cy = 0
            playerRect.bottom = 100
            playerRect.left = 50
            for row in level2: 
                for col in row:
                    if col == "G":
                        groundRect = pygame.Rect(gx,gy,50,50)
                        grounds.append(groundRect)
                    elif col == "S":
                        sideRect = pygame.Rect(sx,sy,50,50)
                        sides.append(sideRect)
                    elif col == "E":
                        enemyRect = pygame.Rect(ex,ey,50,50)
                        enemys.append(enemyRect)
                        enemySpeed.append(eSpeed)
                    elif col == "C":
                        clearRect = pygame.Rect(cx,cy,50,50)
                        clears.append(clearRect)
                    gx = gx + 50
                    sx = sx + 50
                    ex = ex + 50
                    cx = cx + 50
                gy = gy + 50
                gx = 0
                sy = sy + 50
                sx = 0
                ey = ey + 50
                ex = 0
                cx = 0
                cy = cy + 50
            doorRect = pygame.Rect(1100,481,50,100)
            one = False
            two = False
            three = False
            four = False
            five = True
            six = False
            
            stageFive = False
            
        while stageSix == True:
            level3 = [
            "                       S",
            "                    GGGS",
            "                       S",  
            "                 GGG   S",
            "           C  E    E   S", 
            "            GGGGGGGGGGGS",
            "      GGG              S",  
            "C              E  C    S",   
            "        E C   GGGG     S",
            "GGGGGGGGGG             S",
            "GGGGGGGGGG             S",
            "GGGGGGGGGG             S"
            ]
            grounds = []
            sides = []
            enemys = []
            enemySpeed = []
            gx = 0
            gy = 0
            sx = 0
            sy = 0
            ex = 0
            ey = 0
            cx = 0
            cy = 0
            playerRect.bottom = 350
            playerRect.left = 50
            doorRect = pygame.Rect(-100,-100,50,100)
            for row in level3: 
                for col in row:
                    if col == "G":
                        groundRect = pygame.Rect(gx,gy,50,50)
                        grounds.append(groundRect)
                    elif col == "S":
                        sideRect = pygame.Rect(sx,sy,50,50)
                        sides.append(sideRect)
                    elif col == "E":
                        enemyRect = pygame.Rect(ex,ey,50,50)
                        enemys.append(enemyRect)
                        enemySpeed.append(eSpeed)
                    elif col == "C":
                        clearRect = pygame.Rect(cx,cy,50,50)
                        clears.append(clearRect)
                    gx = gx + 50
                    sx = sx + 50
                    ex = ex + 50
                    cx = cx + 50
                gy = gy + 50
                gx = 0
                sy = sy + 50
                sx = 0
                ey = ey + 50
                ex = 0
                cx = 0
                cy = cy + 50
            winRect = pygame.Rect(1100,0,50,50)
            one = False
            two = False
            three = False
            four = False
            five = False
            six = True
            
            stageSix = False
            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game = False
            #when key is pressed
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_a:
                    dx = -xSpeed
                    left = True
                    right = False
                elif event.key == pygame.K_d:
                    dx = xSpeed
                    right = True
                    left = False
                elif event.key == pygame.K_w:
                    for groundBlock in grounds:
                        if playerRect.bottom == groundBlock.top:
                            dy = ySpeed
                            jump = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                if right == True:
                    if bulletSpeed < 0:
                        bulletSpeed = -bulletSpeed
                    else:
                        bulletSpeed = bulletSpeed
                    bx = playerRect.right
                elif left == True:
                    if bulletSpeed > 0:
                        bulletSpeed = -bulletSpeed
                    else:
                        bulletSpeed = bulletSpeed
                    bx = playerRect.left
                by = playerRect.centery
                bulletRect = pygame.Rect(bx,by,15,15)
                bulletInfo = (bulletRect,bulletSpeed)
                bullets.append(bulletInfo)
                
            #when key is up
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    dx = 0
                elif event.key == pygame.K_d:
                    dx = 0
        screen.blit(levelTwoImg,(0,0))
        #BLITTING ALL FOR LOOPS
        #blit images of ground and sides
        for g in grounds:
            screen.blit(ground2,(g))
            #Wall side
        for side in sides:
            screen.blit(wallImg2, (side))
        #lives box
        for heart in lives:
            screen.blit(heartImg,(heart))
        #enemy
        count = 0
        for i in enemys:
            if enemySpeed[count]> 0:
                screen.blit(ghostRight,(i))
            elif enemySpeed[count] < 0:
                screen.blit(ghostLeft,(i))
            i.x += enemySpeed[count]
            count = count + 1
        #bullet speeds
        for bullet in bullets:
            screen.blit(orbOne,(bullet[0]))
            bullet[0].x += bullet[1]
        #CHARACTER    
        #movment of y and x position of character
        playerRect.x += dx
        playerRect.y += dy

        #win and flag obtacles
        screen.blit(door, (doorRect))
        
        #screen.blit(winImg,(winRect))
        #COLLISION
        #end of map
        if playerRect.left < screenRect.left:
            playerRect.left = screenRect.left
        elif playerRect.right > screenRect.right:
            playerRect.right = screenRect.right
        elif playerRect.colliderect(screenRect):
            if playerRect.bottom > screenRect.bottom and len(lives)is not 0:
                lives.pop(len(lives)-1)
                playerRect.y += -100
                if len(lives) == 0:
                    gameOver = True
                    levelOne = False
                    levelTwo = False
                    
        #JUMPING
        if jump == True:
            for groundBlock in grounds:
                #vertex of jump    
                if playerRect.colliderect(groundBlock):
                    if ((groundBlock.top-playerRect.bottom) >= 125):
                        dy = -dy     
                #ground landed on for bottom left corner
                if groundBlock.collidepoint(playerRect.left+1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                       dy = 0
                       jump = False
                #ground landed on for bottom right corner
                if groundBlock.collidepoint(playerRect.right-1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                       dy = 0
                       jump = False                
                       
            #the underside of ground block           
            for groundBlock in grounds:
                #if collides with players top left corner
                if dx > 0:
                    if groundBlock.collidepoint(playerRect.left+1,playerRect.top):
                        playerRect.top = groundBlock.bottom
                        dy = 0
                #if collides with players top right corner
                elif dx < 0:
                    if groundBlock.collidepoint(playerRect.right-1,playerRect.top):
                        playerRect.top = groundBlock.bottom
                        dy = 0
                elif dx == 0:
                    if groundBlock.collidepoint(playerRect.right-1,playerRect.top) or groundBlock.collidepoint(playerRect.left+1,playerRect.top):
                        playerRect.top = groundBlock.bottom
                        dy = 0

            for s in sides:
                #if collides with players top left corner
                if s.collidepoint(playerRect.left,playerRect.top):
                    playerRect.top = s.bottom
                    dy = 0
                #if collides with players top right corner
                elif s.collidepoint(playerRect.right,playerRect.top):
                    playerRect.top = s.bottom
                    dy = 0
                    
        #NOT JUMPING
        #RIGHT
        if jump == False:
            playerRect.y += fall
            for groundBlock in grounds:
                #if player collides with top ground wall
                #playerys bottom left corner    
                if groundBlock.collidepoint(playerRect.left+1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                #players bottom right right corner
                elif groundBlock.collidepoint(playerRect.right-1,playerRect.bottom):
                    if playerRect.bottom > groundBlock.top:
                       playerRect.bottom = groundBlock.top
                #colliding with sides
                if playerRect.colliderect(groundBlock):
                    if dx > 0: # walking to the right
                        if playerRect.right > groundBlock.left: #colliding left side of wall
                            playerRect.right = groundBlock.left  
                            dx = 0
                    elif dx < 0: #walking to the left
                        if playerRect.left < groundBlock.right: #colliding right side of wall
                            playerRect.left = groundBlock.right  
                            dx = 0
        #arching of jump
        if jump == True:
            dy = dy + 3
                
        #SIDE WALLS
        for sideCollide in sides:
            #player
            #colliding with sides
            if playerRect.colliderect(sideCollide):
                if dx > 0: # walking to the right
                    if playerRect.right > sideCollide.left: #colliding left side of wall
                        playerRect.right = sideCollide.left  
                        dx = 0
                elif dx < 0: #walking to the left
                    if playerRect.left < sideCollide.right: #colliding right side of wall
                        playerRect.left = sideCollide.right  
                        dx = 0
            #enemy
            countOne = 0
            for enemy in enemys:
                #left side of wall
                if enemy.colliderect(sideCollide):
                    enemySpeed[countOne] = -enemySpeed[countOne]
                countOne += 1

            #bullet collision
            countTwo = 0
            for b in bullets:
                if b[0].colliderect(sideCollide):
                    if b[1] > 0:#to the right
                        if b[0].right > sideCollide.left:
                            b[0].right = sideCollide.left
                            bullets.pop(countTwo)
                    elif b[1] < 0: #to the left
                        if b[0].left < sideCollide.right:
                            b[0].left = sideCollide.right
                            bullets.pop(countTwo)
                countTwo += 1       

        #bullet to wall collision    
        for groundBlock in grounds:
            countThree = 0
            for b in bullets:
                if b[0].colliderect(groundBlock):
                    if b[1] > 0:
                        if b[0].right > groundBlock.left:
                            b[0].right = groundBlock.left
                            bullets.pop(countThree)
                    elif b[1] < 0:
                        if b[0].left < groundBlock.right:
                            b[0].left = groundBlock.right
                            bullets.pop(countThree)
                countThree += 1    
        #enemy
        #if walking to the right (positive direction)
        countFive = 0
        for enemy in enemys:
            if playerRect.colliderect(enemy) and len(lives) is not 0:
                if dx > 0:
                    if playerRect.left < enemy.right:
                        length = len(lives)
                        lives.pop(length-1)
                        playerRect.x += -70
                        playerRect.y += -50
                elif dx < 0:
                    if playerRect.right > enemy.left:
                        length = len(lives)
                        lives.pop(length-1)
                        playerRect.x += 70
                        playerRect.y += -50                    
                else:
                    length = len(lives)
                    lives.pop(length-1)
                    playerRect.x += 100
                    playerRect.y += -50
                    
            if enemy.colliderect(doorRect):
                enemySpeed[countFive] = -enemySpeed[countFive]
                countFive += 1
            countFive = 0
            
        if len(lives) == 0 or len(lives)<0:
            levelOne = False
            levelTwo = False
        
            gameOver = True
            
        #enemy collision to bullets
        countEight = 0
        countFour = 0
        for enemy in enemys:
            for bullet in bullets:
                countFour = 0
                if bullet[0].colliderect(enemy):
                    bullets.pop(countFour)
                    enemys.pop(countEight)
                    score += 100
                countFour += 1
            countEight += 1           
            
        #enemy to clear
        for clear in clears:
            countSix = 0
            for enemy in enemys:
                if enemy.colliderect(clear):
                    enemySpeed[countSix]= -enemySpeed[countSix]
                countSix += 1
        #if enemy touches ground block
        for groundBlock in grounds:
            countSeven = 0
            for enemy in enemys:
                if enemy.colliderect(groundBlock):
                    if enemySpeed[countSeven] > 0:
                        if enemy.right > groundBlock.left:
                            enemySpeed[countSeven] = -enemySpeed[countSeven]    
                    elif enemySpeed[countSeven] < 0:
                        if enemy.left < groundBlock.right:
                            enemySpeed[countSeven] = -enemySpeed[countSeven]
                countSeven += 1
        #stages on door collision 
        #stages on door collision 
        if one == True:
            if playerRect.colliderect(doorRect):
                stageTwo = True
        elif two == True:
            if playerRect.colliderect(doorRect):
                stageThree = True
        elif three == True:
            screen.blit(winImgOne,(winRect))
            if playerRect.colliderect(winRect):
                levelOne = False
                win = True
        elif four == True:
            if playerRect.colliderect(doorRect):
                stageFive = True
        elif five == True:
            if playerRect.colliderect(doorRect):
                stageSix = True
        elif six == True:
            screen.blit(winImgTwo,(winRect))
            if playerRect.colliderect(winRect):
                levelTwo = False
                
        scoreText = font[6].render(str(score),True,colour[1])
        screen.blit(scoreText,(165,2))
        #blit character
        if right == True:
            screen.blit(charRight, (playerRect))
        elif left == True:
            screen.blit(charLeft,(playerRect))
        pygame.display.flip()
        pygame.display.update()
        clock.tick(FPS)
    while win == True:
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                mousePressed(event)
            elif event.type == pygame.QUIT:
                game = False
        screen.fill(colour[0])
        screen.blit(winBackground,(0,0))
        
        winText = font[4].render("You Win!",True,colour[3])
        winTextRect = pygame.Rect(width/2-winText.get_width()/2,100,winText.get_width(),winText.get_height())
        screen.blit(winText, (winTextRect))

        playAgain = font[0].render("Play Again",True,colour[6])
        playAgainRect =  pygame.Rect(winTextRect.left,winTextRect.bottom+30,playAgain.get_width(),playAgain.get_height())
        screen.blit(playAgain, (playAgainRect))

        menuText = font[0].render("Menu",True,colour[7])
        menuRect =  pygame.Rect(playAgainRect.right+10,winTextRect.bottom+30,menuText.get_width(),menuText.get_height())
        screen.blit(menuText, (menuRect))

        quitText = font[0].render("Quit",True,colour[8])
        quitRect =  pygame.Rect(menuRect.right+10,winTextRect.bottom+30,quitText.get_width(),quitText.get_height())
        screen.blit(quitText, (quitRect))

        if playAgainRect.collidepoint(mousePos) and clicked == True:
            gameOver = False
            win = False
            clicked = False
            if one == True or two == True or three == True:
                levelOne = True
                stageOne = True
            elif four == True or five == True or six == True:
                levelTwo = True
                stageFour = True
                
        elif menuRect.collidepoint(mousePos) and clicked == True:
            gameOver = False
            win = False
            menu = True
            clicked = False
            levelOne = False
            levelTwo = False
            levelThree = False
            stageOne = False
            stageTwo = False
            stageThree = False
            stageFour = False
            stageFive = False
            stageSix = False
            one = False
            two = False
            three = False
            four = False
            five = False
            six = False
        elif quitRect.collidepoint(mousePos) and clicked == True:
            pygame.quit()
            sys.exit()
        
        pygame.display.update()
        clock.tick(FPS)

            
        
pygame.quit()
sys.exit()
