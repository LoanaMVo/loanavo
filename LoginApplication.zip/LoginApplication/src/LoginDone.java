import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
/*
 * This class displays when the user is finished and done with their login.
 */
public class LoginDone{
	static Button ok;
	/*
	 * methods displays all the labels, grid and buttons placed in the window. 
	 */
    static void displayWindow(){
		Stage window = new Stage();
		window.setTitle("Sign Up Window");
		//grid
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10,10,10,10));
		
		//title
		Label title = new Label("Login was sucessful!!!");
		GridPane.setConstraints(title,0,0);
		//submit button
		ok  = new Button();
		ok.setText("Ok");
		GridPane.setConstraints(ok, 0,1);	
		grid.getChildren().addAll(title, ok);
		Scene scene = new Scene(grid,500,300);
		window.setScene(scene);
		window.show();
		
		ok.setOnAction(e -> {
			window.close();
		});
		
	}  
    
}
