import java.io.FileNotFoundException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/*
 * This class is the user interfce for the login window, containing the textfields, labels, grid
 * and etc for the login window. Users can login through entering a username and its matching password or open a signup window
 * to create a new user.		
 */
public class LoginWindow extends Application{
	private static Stage window;
	public static void main(String[] args) {
		launch(args);
	}
	/*
	 * Start contains all information such as labels,buttons and textifields for the stage login.
	 */
	public void start(Stage primaryStage) throws Exception{
		ArrayList<Label> myStars = new ArrayList<Label>();
		window = primaryStage;
		window.setTitle("Login Window");
		//grid
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10, 10, 10, 10));

		//Title
		Label title = new Label("Login");
		GridPane.setConstraints(title, 0, 0);
		//aestricks
		Label aestrickOne = new Label(" *");
		Label aestrickTwo = new Label(" *");
		myStars.add(aestrickOne);
		myStars.add(aestrickTwo);
		//setting aestrick label colours.
		for(int i = 0; i < myStars.size(); i++){
			myStars.get(i).setTextFill(Color.web("#ff2200"));
			setVisible(myStars.get(i), false);
			GridPane.setConstraints(myStars.get(i), 2, i+1);
		}
		
		//username label
		Label nameLabel = new Label("User Name: ");
		GridPane.setConstraints(nameLabel, 0, 1);
		//username input
		TextField nameInput = new TextField();
		nameInput.setPromptText("username"); //prompt text
		GridPane.setConstraints(nameInput, 1, 1);
		//password label
		Label passwordLabel = new Label("Password: ");
		GridPane.setConstraints(passwordLabel, 0, 2);
		//password input
		PasswordField passwordInput = new PasswordField();
		passwordInput.setPromptText("password"); //prompt text
		GridPane.setConstraints(passwordInput, 1, 2);
		//sign up button
		Button btnSignUp = new Button("Sign Up");
		GridPane.setConstraints(btnSignUp, 0, 3);
		//login button
		Button btnLogin = new Button("Login");
		GridPane.setConstraints(btnLogin, 1,3);
	    //cancel button
		
		grid.getChildren().addAll(title, nameLabel, nameInput, passwordLabel, passwordInput, btnSignUp, btnLogin, aestrickOne, aestrickTwo);
		
		Scene scene = new Scene(grid,500,300);
		window.setScene(scene);
		window.show();

		//login
		btnLogin.setOnAction(e -> {
			if(errorCheck(nameInput.getText(), passwordInput.getText(), myStars)){
				nameInput.setText("");
				passwordInput.setText("");
			}
		});
		
		btnSignUp.setOnAction(e -> {
			SignUp.signUp();
			
     	});
	}
	
	/*
	 * This method takes in a string for a username, password and an arraylist containing labels.
	 * runs through all scenatrios or error and checks if the text fields are empty. 
	 * checks user input for names and passwords. If passwords and names match or whether they don't,
	 * user may be allowed to login. Returns true or false based on the output and sets fields 
	 * to empty.
	 */
	private boolean errorCheck(String nameInput, String passwordInput, ArrayList<Label> myList){		
		boolean missing = false;
		// make sure field is full
		boolean[] boolList = new boolean[] {nameInput.equals(""), passwordInput.equals("")};
		for(int i = 0; i < boolList.length; i++){
			if(boolList[i]){
				missing = true;//there is a missing field
				setVisible(myList.get(i), true);
			}else{
				setVisible(myList.get(i), false);
			}
		}
		if(missing){
			PopUp.display("Missing field", "Missing field (*)");
			return false;
		}else if(ReadInput.passwordUsername(nameInput, passwordInput)){//username and password
			LoginDone.displayWindow();
			window.close();
		}else if(ReadInput.usernameMatch(nameInput, passwordInput) && !ReadInput.passwordMatch(nameInput, passwordInput)){//password does not match
				PopUp.display("Incorrect Password", "The password entered is incorrect!");
		}else{
			PopUp.display("Incorrect login", "Incorrect username and password!");
		}
		return true;
		
	}
	
	/*
	 * this method sets a label passed through to false or true for visibility. 
	 */
	private static void setVisible(Label label, boolean set){
		label.setVisible(set);
	}

	
	
}