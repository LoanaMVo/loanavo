import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/*
 * This class controls the window display of a popup messgae for errors
 */
public class PopUp {
	static void display(String title, String message){
		Stage window = new Stage();
		//forces user to ???
		window.initModality(Modality.APPLICATION_MODAL);
	
		window.setTitle(title);
		window.setMinWidth(250);
		
		Label label = new Label(message);
		
		Button okButton = new Button("Ok");
		okButton.setOnAction(e->{
			window.close();
		});				
		
		VBox layout = new VBox(10);
		layout.getChildren().addAll(label, okButton);
		layout.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.showAndWait();
	}


}
