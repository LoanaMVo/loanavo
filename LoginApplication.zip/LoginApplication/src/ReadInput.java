import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadInput {
	/*
	 * returns true or false for the number retured from the findInput method for username and password match
	 */
	static boolean passwordUsername(String username, String password){
		if(findInput(username, password) == 0){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * returns true or false for the number retured from the findInput method for username match
	 */
	
	static boolean usernameMatch(String username, String password){
		if(findInput(username, password) == 1){
			return true;
		}else{
			return false;
		}
	}
	/*
	 * returns true or false for the number retured from the findInput method for password match
	 */    
	static boolean passwordMatch(String username, String password){
		if(findInput(username, password) == 2){
			return true;
		}
		return false;
	}
	/*
	 * this method opens the file for usernames and passwords. Reads the lines and finds whether the inputted usernames and password
	 * strings from the user match with the username and passwords within the file.
	 */
	@SuppressWarnings("resource")
	private static int findInput(String inputOne, String inputTwo){		
			File loginText = new File("passwordAndUsernames.txt");
			try {
				BufferedReader getInfo = new BufferedReader(
						new FileReader(loginText));
				String loginLine = getInfo.readLine();
				//read and repeat
				while(loginLine != null){	
					//String split = " " + "," ;
					String[] indivInfo = loginLine.split(" ");
						indivInfo[1] = indivInfo[1].substring(0, indivInfo[1].length()-1);//erases the comma from the string
						if(indivInfo[0].equals(inputOne) && indivInfo[1].equals(inputTwo)){//user and password on same line
							return 0;
						}else if(indivInfo[0].equals(inputOne)){//username
							return 1;
						}else if(indivInfo[1].equals(inputTwo)){//password
							return 2;
						}
						//indivInfo = loginLine.split(",");
					loginLine = getInfo.readLine();
				}
			} 		
			// Can be thrown by FileReader
			catch (FileNotFoundException e) {
				System.out.println("Couldn't Find the File");
				System.exit(0);
			}
			catch(IOException e){
				System.out.println("An I/O Error Occurred");
				System.exit(0);
			}
			return 3;
		}	

}


