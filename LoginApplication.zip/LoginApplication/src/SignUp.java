import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.control.TextField;

/*
 * Signup class controls and handels all userinputs for creating a new user such as username, 
 * the password and the confirm password.
 */
public class SignUp {
	static Button submit, cancel;

	/*
	 * This method creates another interfacce for the user for logging in. 
	 * The user cannot close the login window unless this signup window has
	 * been taken care of whether its been closed manually or if the signup
	 * process was successful.
	 */
	static void signUp() {
		ArrayList<Label> myStars = new ArrayList<Label>();
		
		Stage window = new Stage();
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Sign Up Window");
		// grid
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10, 10, 10, 10));
		// title
		Label title = new Label("Sign Up");
		GridPane.setConstraints(title, 0, 0);
		// username label
		Label nameLabel = new Label("Enter a user name:");
		GridPane.setConstraints(nameLabel, 0, 1);
		//aestricks
		Label aestrickOne = new Label(" *");
		Label aestrickTwo = new Label(" *");
		Label aestrickThree = new Label(" *");
		myStars.add(aestrickOne);
		myStars.add(aestrickTwo);
		myStars.add(aestrickThree);
		
		for(int i = 0; i < myStars.size(); i++){
			myStars.get(i).setTextFill(Color.web("#ff2200"));
			setVisible(myStars.get(i), false);
			GridPane.setConstraints(myStars.get(i), 2, i+1);
		}
		// input
		TextField nameInput = new TextField();
		nameInput.setPromptText("username"); // prompt text
		GridPane.setConstraints(nameInput, 1, 1);
		// set password
		Label passwordLabel = new Label("Enter a password:");
		GridPane.setConstraints(passwordLabel, 0, 2);
		// input
		PasswordField passwordInput = new PasswordField();
		passwordInput.setPromptText("password"); // prompt text
		GridPane.setConstraints(passwordInput, 1, 2);
		// set confirm password
		Label passwordConfirmLabel = new Label("Confirm password:");
		GridPane.setConstraints(passwordConfirmLabel, 0, 3);
		// input
		PasswordField confirmInput = new PasswordField();
		confirmInput.setPromptText("password"); // prompt text
		GridPane.setConstraints(confirmInput, 1, 3);
		// submit button
		submit = new Button();
		submit.setText("Submit");
		GridPane.setConstraints(submit, 0, 4);
		// cancel button
		cancel = new Button();
		cancel.setText("Cancel");
		GridPane.setConstraints(cancel, 1, 4);

		// passwordInput.setVisible(false);
		grid.getChildren().addAll(title, nameLabel, passwordLabel, passwordConfirmLabel, nameInput, passwordInput, confirmInput, submit, cancel, aestrickOne, aestrickTwo, aestrickThree);
		Scene scene = new Scene(grid, 500, 300);
		window.setScene(scene);
		window.show();

		submit.setOnAction(e -> {
			errorCheck(nameInput.getText(), passwordInput.getText(), confirmInput.getText(), window, myStars);
		});

		cancel.setOnAction(e -> {
			window.close();
		});
	}
	/*
	 * This controls all error cases for the sign up window.
	 * Whether the username entered already exists, the password length, symbol and captital cases.
	 * If the username and password made are valid, it will write the information to the database.
	 */
	private static void errorCheck(String nameInput, String passwordInput, String confirmInput, Stage window, ArrayList<Label> myList) {
		boolean match = false;
		boolean correct = true;
		boolean missing = false;
		
		// make sure field is full
		boolean[] boolList = new boolean[] {nameInput.equals(""), passwordInput.equals(""), confirmInput.equals("")};
		for(int i = 0; i < boolList.length; i++){
			if(boolList[i]){
				missing = true;//there is a missing field
				setVisible(myList.get(i), true);
			}else{
				setVisible(myList.get(i), false);
			}
		}
		if (missing) {
			PopUp.display("Missing field", "Missing field (*)");
			
		} else {

			if (!correctLength(nameInput) || !correctLength(passwordInput)) {
				PopUp.display("Username and password Length",
						"Username and password must be 6-10 characters long.");
			} else {
				if (!passwordCheck(passwordInput)) {
					PopUp.display("Incorrect password!", "Password must contain a capital letter and a symbol.");

				} else {
					// Match username
					if (ReadInput.usernameMatch(nameInput, passwordInput)) {
						PopUp.display("Username", "That username already exists!");
						correct = !correct;
					}
					// password confirm is the same
					else if (passwordInput.equals(confirmInput)) {
						match = true;
					}
					// password confirm is not the same
					else if (!match) {
						PopUp.display("Password", "Password does not match!");
						correct = !correct;
					}
					if (correct) {
						WriteInput.addToText(nameInput, passwordInput);
						PopUp.display("Sign Up", "Sign up was successful, you account has been created!");
						window.close();
					}
				}
			}
		}
	}
	/*
	 * This method checks the username and password length and returns 
	 * true or false whether they meet the correct conditions of 6-10
	 * characters.
	 */
	private static boolean correctLength(String input) {
		int length = input.length();
		if (length > 10 || length < 6) {
			return false;
		} else {
			return true;
		}
	}

	/*
	 * Checks is password contains: a captial letter and a symbol:
	 * "!" "@" "#" "$" "%" "^" "&" "*"
	 */
	private static boolean passwordCheck(String password) {
		char[] symbols = new char[] { '!', '@', '#', '$', '%', '^', '&', '*' };
		boolean a = false;
		boolean b = false;
		for (int i = 0; i < password.length(); i++) {
			if (Character.isUpperCase(password.charAt(i))) {
				a = true;
			}
			for (int j = 0; j < symbols.length; j++) {
				if (password.charAt(i) == symbols[j]) {
					b = true;
				}
			}
		}
		if (a == true && b == true) {
			return true;
		} else {
			return false;
		}
	}
	
	/*
	 * Method makes the labelled passed as either visible or invisible.
	 */
	private static void setVisible(Label label, boolean set){
		label.setVisible(set);
	}
}
