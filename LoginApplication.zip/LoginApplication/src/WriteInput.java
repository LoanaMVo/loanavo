import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
/*
 * Class opens a file where all username and password information is being stored. 
 * It appends the username and password to the end of the file.
 */
public class WriteInput {	
	/*
	 * opens file and returns the file.
	 */
	private static PrintWriter openFile(String fileName){	
		try{
			// Creates a File object that allows you to work with files on the hardrive
			File listOfInfo = new File(fileName);
			PrintWriter infoToWrite = new PrintWriter(
			new BufferedWriter(
					new FileWriter(listOfInfo, true))
			);
			return infoToWrite;
		}
		// You have to catch this when you call FileWriter
		catch(IOException e){
			System.out.println("An I/O Error Occurred");
			System.out.println(e);
			// Closes the program
			System.exit(0);
		}
		return null;	
	}
	/*
	 * takes in username and password strings and writes them into the file.
	 */
	static void addToText(String username, String password){
		PrintWriter file = openFile("passwordAndUsernames.txt");
		String info = username + " " + password + "," + "\n";
		String infoNew = info.replaceAll("\n", System.lineSeparator());
		file.append(infoNew);
		file.close();	
		}
}