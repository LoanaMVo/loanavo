import java.util.Scanner;

/*
 * This class plays the game tic tac toe, containing the game methods for user to play tic tac toe with ai.
 */
public class TicTacToe {
	static String[][] board = new String[3][3];
	static int[] moves = new int[10];
	static Scanner input = new Scanner(System.in);

	/*
	 * Main method welcomes the user into the game and calls on all game functions. 
	 */
	public static void main(String[] args) {
		int play = 0;
		boolean game = true;
		while(game)
			switch(play){
			case 0://game play
				System.out.println("Welcome to Tic Tac Toe!");
				
				System.out.println("Would you like to play with AI?");
				String choice = ask();
				boolean aiChoice = false;
				if(choice.equalsIgnoreCase("yes")){
					aiChoice = true;
				}
				String player = " o ";
				drawBoard(board);//draws board

				do {
					player = changePlayer(player);//changes player
					updatedBoard(board, userInput(moves), player);// updated board calls for user input
					drawBoard(board);//draws board
					if(aiChoice == true){
						player = changePlayer(player);
						updatedBoard(board, ai(moves), player);
						drawBoard(board);//draws board
					}
				} while (!isFull(board) && !winnerCheck(board, player));//while the board is not full and there is no winner
				//drawBoard(board);
				if (isFull(board) && !winnerCheck(board, player)) {//if the board is full and there is no winner. 
					System.out.println("Tie game!");//Tie game
				}else{
					System.out.println("Player " + player + " wins!");
				}
				
			case 1://end game
				System.out.println("Would you like to play again? (yes or no)");
				String answer = ask();
				if(answer.equalsIgnoreCase("yes")){
					resetBoard(board, moves);
					break;
				}
			case 2://ai
				
			default://player doesn't want to play again
				System.out.println("Thank you for playing the game!");
				game = false;
				break;
			}
	}
	
	/*
	 * Method resets board by looping through each list and clearing them.
	 */
	private static void resetBoard(String a[][], int b[]){
		for(int i = 0; i < a.length; i++){
			for(int j = 0; j < a[i].length; j++){
				a[i][j] = "   ";				
			}
		}
		for(int i = 0; i < 10; i++){
			b[i] = 10;
		}
	}
	/*
	 * Method asks for user input to see if they would like to play again or not.
	 */
	private static String ask(){
		String answer;
		
		while (true)
			try {
				answer = input.nextLine();
				if (answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")) {
					break;
				}else{
					throw new IllegalArgumentException();
				}
			} catch (Exception nfe) {
				System.out.println("Try again. (yes or no)");
			}
		return answer;
	}
	
	/*
	 * Method draws the board by looping through the list and printing out the board.
	 */
	private static void drawBoard(String a[][]) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (a[i][j] == null) {
					a[i][j] = "   ";
				}
				System.out.print(a[i][j]);
				if (j < a[i].length - 1) {
					System.out.print("|");
				}
			}
			if (i < a.length - 1) {
				System.out.println();
				System.out.println("�����������");
			}
		}
		System.out.println();
	}

	/*
	 * Method places the move onto the board by looping through the board and 
	 * the location, adding it into the board.
	 */
	private static void updatedBoard(String a[][], int place, String b) {
		for (int i = 0; i < 10; i++) {
			if (place == (i + 1)) {
				if (place < 4) {
					a[0][place - 1] = b;
				} else if (place < 7) {
					a[1][place - 4] = b;
				} else if (place < 10) {
					a[2][place - 7] = b;
				}
			}
		}

	}

	/*
	 * Checks to see if the board is full or not by looping through the board
	 * and checking for a blank space. Returns false if the board is not full
	 * and returns true if the board is found to be full. 
	 */
	private static boolean isFull(String a[][]) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (a[i][j].equals("   ")) {
					return false;
				}
			}
		}
		return true;
	}

	/*
	 * Asks the user through the scanner for an input value between 1 - 9. Tries
	 * the input and catches if there are any errors with the input; loops until
	 * a valid input was entered. If number is anything other than 1-9, it will throw
	 * and error and keep trying for user input.
	 * Returns the num.
	 */
	private static int userInput(int a[]) {
		System.out.println("Input move. (1, 2, 3, 4, 5, 6, 7, 8, 9)");
		int num = 0;
		while (true)
			try {
				num = Integer.parseInt(input.nextLine());
				if (num < 1 || num > 9) {
					throw new IllegalArgumentException();
				}
				for (int i = 0; i < a.length; i++) {
					if (num == a[i]) {
						System.out.println("This spot is already taken.");
						throw new IllegalArgumentException();
					}
				}
				break;
			} catch (Exception nfe) {
				System.out.println("Try again. Enter in a number between (1 - 9).");
			}
		a[num - 1] = num;
		return num;
	}

	/*
	 * This method checks for the winner, loops through  for loops to check the 2D array.
	 * Checks if the index of the same int is equal in each first index (x) of the array to
	 * see if there is a winner for columns. Checks row by looking at each first array to
	 * check if the 2nd array (y) row is equal to each other for a winner for rows. Manually 
	 * checks the diagonal going up and down to see if there is a winner for diagonals. 
	 */
	private static boolean winnerCheck(String a[][], String player) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (a[i][j] != "   ") {
					if (a[0][j].equals(a[1][j]) && a[1][j].equals(a[2][j])) {// column															// check
						return true;
					} else if (a[i][0].equals(a[i][1]) && a[i][1].equals(a[i][2])) {// row																		
						return true;
					}
				
					if (a[1][1] != "   ") {
						if (a[0][0].equals(a[1][1]) && a[1][1].equals(a[2][2])) {// diagonal, down
							return true;
						} else if (a[0][2].equals(a[1][1]) && a[1][1].equals(a[2][0])) {//diagonal, up
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	/*
	 * Switches player turns by checking to see if the player is equal to x or o 
	 * and then switches them to the other player. Prints out the player turn and 
	 * returns the new player. 
	 */
	private static String changePlayer(String a) {
		String newPlayer = "";
		if (a.equals(" x ")) {
			newPlayer = " o ";
		} else if (a.equals(" o ")) {
			newPlayer = " x ";
		}
		System.out.println("It is " + newPlayer + "'s turn.");
		return newPlayer;
	}
	/*
	 * Random ai, repeats and looks for a number between 1 - 9 by looping
	 * through a while loop and setting boolean condition to set a place
	 * location for the move.
	 */
	private static int ai(int a[]){
		int place = 0;
		boolean repeat = true;
		boolean sameNum = false;
		while(repeat){
			place = (int)Math.ceil(Math.random()*9);
				for(int i = 0; i < 10; i++){
					if(a[i] == place){
						sameNum = true;
					}
				}
				if(!sameNum){
					repeat = false;
				}
		}
			return place;
	}

}
